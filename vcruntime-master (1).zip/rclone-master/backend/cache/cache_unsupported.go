// Build for cache for unsupported platforms to stop go complaining
// about "no buildable Go source files "

// +build plan9

package cache

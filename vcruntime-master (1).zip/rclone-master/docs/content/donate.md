---
title: "Flowers for My Wife"
description: "Flowers for My Wife."
type: page
date: "2015-09-06"
---

## <i class="fa fa-heart"></i> Flowers for My Wife ##

Rclone is a pure open source for love-not-money project.  However I've
had requests for a donation page and coding rclone does take me away
from something else I love - my wonderful wife.

So if you would like to send a donation, I will use it to buy flowers
(and other pretty things) for her which will make her very happy.

### Paypal ###

<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="XQMMNUD5ZY49J">
<input type="image" src="https://www.paypalobjects.com/en_US/GB/i/btn/btn_donateCC_LG.gif" border="0" name="submit" alt="PayPal – The safer, easier way to pay online.">
<img alt="" border="0" src="https://www.paypalobjects.com/en_GB/i/scr/pixel.gif" width="1" height="1">
</form>

### Paypal.me ###

My paypal.me link https://www.paypal.me/nickcw can be used to send
money if the donate button doesn't work for you (eg you live in
Japan), or if you prefer to use it.

### Bitcoin ###

[![19j3oLUsqBcTRvZ2LSq2phVjsAAJ86xSnk](/img/ncw-bitcoin-address.png)](bitcoin:19j3oLUsqBcTRvZ2LSq2phVjsAAJ86xSnk)

[Bitcoin:](bitcoin:19j3oLUsqBcTRvZ2LSq2phVjsAAJ86xSnk) 19j3oLUsqBcTRvZ2LSq2phVjsAAJ86xSnk

If you would prefer to express your gratitude by promoting the
project, or helping with it, I'd be over the moon with that too!

Thanks

Nick